package Spel;

public class computer {
    
}
